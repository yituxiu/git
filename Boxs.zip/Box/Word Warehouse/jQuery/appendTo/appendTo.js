$(function (){
$("div").appendTo("b")	////把div落到b标签的内容后面去
})